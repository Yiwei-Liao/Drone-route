"""阶段 2 数据标准化脚本入口。"""

from __future__ import annotations

import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from backend.taishan_pipeline.process_data import main  # noqa: E402


if __name__ == "__main__":
    raise SystemExit(main())
